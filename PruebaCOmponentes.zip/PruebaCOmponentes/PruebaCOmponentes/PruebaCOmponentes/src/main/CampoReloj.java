package main;

import com.raven.swing.TimePicker;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/**
 * Componente visual personalizado para la selección de horas y minutos en la aplicación LazyTrip.
 * <p>
 * Presenta un campo de texto redondeado a la izquierda junto a un botón con icono
 * de reloj a la derecha. Al hacer clic en el icono, despliega un {@link JPopupMenu}
 * con un selector analógico ({@link TimePicker}) que permite seleccionar horas y minutos
 * tanto en incrementos de 5 como mediante el arrastre preciso de la aguja.
 * </p>
 *
 * @author Alejandro Moreno Luna
 * @version 1.0
 * @since 2026-11
 */
public class CampoReloj extends JPanel {

    private final JTextField txtHora;
    private final JButton btnIconoReloj;
    private final JPopupMenu popupReloj;
    private final TimePicker timePicker;
    private LocalTime horaSeleccionada;

    /**
     * Construye una nueva instancia de {@code CampoReloj} con sus valores por defecto:
     * campo de texto vacío, hora seleccionada en {@code null} y selector analógico configurado
     * en modo 24 horas dentro de un menú emergente oculto.
     */
    public CampoReloj() {
        setLayout(new BorderLayout(10, 0));
        setOpaque(false);
        setPreferredSize(new Dimension(280, 44));
        setBorder(new EmptyBorder(6, 16, 6, 12));

        // 1. Campo de texto izquierdo
        txtHora = new JTextField();
        txtHora.setName("txtHora");
        txtHora.setEditable(false);
        txtHora.setOpaque(false);
        txtHora.setBorder(null);
        txtHora.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtHora.setForeground(new Color(45, 55, 72));
        txtHora.setToolTipText("HH:mm");

        // 2. Botón con icono vectorial de reloj a la derecha
        btnIconoReloj = new JButton(new IconoReloj());
        btnIconoReloj.setName("btnIconoReloj");
        btnIconoReloj.setContentAreaFilled(false);
        btnIconoReloj.setBorderPainted(false);
        btnIconoReloj.setFocusPainted(false);
        btnIconoReloj.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnIconoReloj.setPreferredSize(new Dimension(28, 28));

        // 3. Desplegable con el TimePicker analógico de la librería
        popupReloj = new JPopupMenu();
        popupReloj.setName("popupReloj");
        timePicker = new TimePicker();
        timePicker.setName("timePickerInterno");
        timePicker.set24hourMode(true);
        ocultarBotonCancel(timePicker);
        popupReloj.add(timePicker);

        // Evento al clicar el icono de reloj: abre el popup
        btnIconoReloj.addActionListener(e -> {
            popupReloj.show(this, 0, getHeight() + 4);
        });

        // Evento al confirmar hora en el TimePicker (botón OK): escribe HH:mm y cierra popup
        timePicker.addActionListener(e -> {
            Date date = timePicker.getSelectedDate();
            if (date != null) {
                LocalTime lt = date.toInstant().atZone(ZoneId.systemDefault()).toLocalTime().withSecond(0).withNano(0);
                setHora(lt);
            }
            popupReloj.setVisible(false);
        });

        add(txtHora, BorderLayout.CENTER);
        add(btnIconoReloj, BorderLayout.EAST);
    }

    /**
     * Localiza y oculta recursivamente el botón "Cancel" interno del {@link TimePicker}
     * para dejar únicamente el botón de confirmación "OK".
     *
     * @param contenedor contenedor raíz en el que buscar el botón
     */
    private void ocultarBotonCancel(Container contenedor) {
        for (Component comp : contenedor.getComponents()) {
            if (comp instanceof AbstractButton) {
                AbstractButton btn = (AbstractButton) comp;
                if (btn.getText() != null && "Cancel".equalsIgnoreCase(btn.getText().trim())) {
                    btn.setVisible(false);
                    btn.setEnabled(false);
                }
            } else if (comp instanceof Container) {
                ocultarBotonCancel((Container) comp);
            }
        }
    }

    /**
     * Renderiza el contenedor visual con fondo blanco, esquinas redondeadas y borde
     * suavizado mediante antialiasing.
     *
     * @param g contexto gráfico {@link Graphics} utilizado para pintar el componente
     */
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 20, 20));
        g2.setColor(new Color(220, 228, 232));
        g2.draw(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 20, 20));
        g2.dispose();
        super.paintComponent(g);
    }

    /**
     * Obtiene la hora actualmente seleccionada en el componente.
     *
     * @return objeto {@link LocalTime} con la hora y minutos elegidos, o {@code null} si no se ha seleccionado ninguna
     */
    public LocalTime getHora() {
        return horaSeleccionada;
    }

    /**
     * Establece programáticamente una hora en el componente, actualizando tanto el reloj
     * analógico interno como el campo de texto visible en formato {@code HH:mm}.
     *
     * @param hora nueva hora {@link LocalTime} a asignar; si es {@code null}, limpia el campo de texto
     */
    public void setHora(LocalTime hora) {
        this.horaSeleccionada = hora;
        if (hora != null) {
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hora.getHour());
            cal.set(Calendar.MINUTE, hora.getMinute());
            timePicker.setSelectedTime(cal.getTime());
            txtHora.setText(hora.format(DateTimeFormatter.ofPattern("HH:mm")));
        } else {
            txtHora.setText("");
        }
    }

    /**
     * Devuelve la cadena de texto formateada que se muestra actualmente en la barra izquierda.
     *
     * @return texto visible en el campo de hora (por ejemplo, {@code "11:30"} o cadena vacía)
     */
    public String getTextoMostrado() {
        return txtHora.getText();
    }

    /**
     * Proporciona acceso directo a la instancia interna del selector analógico {@link TimePicker},
     * útil para pruebas automatizadas de interfaz y validación de estado.
     *
     * @return instancia interna de {@link TimePicker}
     */
    public TimePicker getTimePicker() {
        return timePicker;
    }

    /**
     * Icono vectorial dibujado mediante primitivas 2D que representa una esfera de reloj
     * sin depender de ficheros externos de imagen.
     *
     * @author Alejandro Moreno Luna
     */
    private static class IconoReloj implements Icon {

        /**
         * Dibuja el icono del reloj en las coordenadas especificadas.
         *
         * @param c componente anfitrión del icono
         * @param g contexto gráfico de renderizado
         * @param x coordenada horizontal inicial
         * @param y coordenada vertical inicial
         */
        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(55, 65, 81));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawOval(x + 2, y + 2, 14, 14);
            g2.drawLine(x + 9, y + 9, x + 9, y + 5);
            g2.drawLine(x + 9, y + 9, x + 12, y + 9);
            g2.dispose();
        }

        /**
         * Devuelve el ancho fijo del icono en píxeles.
         *
         * @return ancho del icono ({@code 18} px)
         */
        @Override
        public int getIconWidth() {
            return 18;
        }

        /**
         * Devuelve el alto fijo del icono en píxeles.
         *
         * @return alto del icono ({@code 18} px)
         */
        @Override
        public int getIconHeight() {
            return 18;
        }
    }
}