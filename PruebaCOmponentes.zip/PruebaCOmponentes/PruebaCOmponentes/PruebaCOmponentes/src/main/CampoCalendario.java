package main;

import com.toedter.calendar.JCalendar;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import java.awt.*;
import java.awt.event.MouseListener;
import java.awt.geom.RoundRectangle2D;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

/**
 * Componente visual personalizado para la selección de fechas en la aplicación LazyTrip.
 * <p>
 * Encapsula un campo de texto de solo lectura a la izquierda y un botón con icono
 * vectorial a la derecha que despliega un calendario emergente ({@link JCalendar})
 * dentro de un {@link JPopupMenu}. Al seleccionar un día, la fecha se formatea y se
 * muestra automáticamente en la barra de texto.
 * </p>
 *
 * @author Alejandro Moreno Luna
 * @version 1.0
 * @since 2026-11
 */
public class CampoCalendario extends JPanel {

    private final JTextField txtFecha;
    private final JButton btnIconoCalendario;
    private final JPopupMenu popupCalendario;
    private final JCalendar jCalendar;
    private LocalDate fechaSeleccionada;

    /**
     * Construye una nueva instancia de {@code CampoCalendario} con sus valores
     * por defecto: campo de texto vacío, fecha seleccionada en {@code null} y
     * panel emergente oculto hasta que el usuario pulse el icono derecho.
     */
    public CampoCalendario() {
        setLayout(new BorderLayout(10, 0));
        setOpaque(false);
        setPreferredSize(new Dimension(280, 44));
        setBorder(new EmptyBorder(6, 16, 6, 12));

        // 1. Campo de texto izquierdo
        txtFecha = new JTextField();
        txtFecha.setName("txtFecha");
        txtFecha.setEditable(false);
        txtFecha.setOpaque(false);
        txtFecha.setBorder(null);
        txtFecha.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtFecha.setForeground(new Color(45, 55, 72));
        txtFecha.setToolTipText("dd/MM/yyyy");

        // 2. Botón con icono vectorial de calendario a la derecha
        btnIconoCalendario = new JButton(new IconoCalendario());
        btnIconoCalendario.setName("btnIconoCalendario");
        btnIconoCalendario.setContentAreaFilled(false);
        btnIconoCalendario.setBorderPainted(false);
        btnIconoCalendario.setFocusPainted(false);
        btnIconoCalendario.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnIconoCalendario.setPreferredSize(new Dimension(28, 28));

        // 3. Desplegable con el JCalendar de la librería
        popupCalendario = new JPopupMenu();
        popupCalendario.setName("popupCalendario");
        jCalendar = new JCalendar();
        jCalendar.setName("jCalendarInterno");
        desactivarDesplegableMes();
        popupCalendario.add(jCalendar);

        // Evento al clicar el icono de la derecha: abre el popup debajo de la barra
        btnIconoCalendario.addActionListener(e -> {
            popupCalendario.show(this, 0, getHeight() + 4);
        });

        // Evento al seleccionar un día en el calendario: escribe en texto y cierra popup
        jCalendar.getDayChooser().addPropertyChangeListener("day", evt -> {
            Date date = jCalendar.getDate();
            setFecha(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
            popupCalendario.setVisible(false);
        });

        add(txtFecha, BorderLayout.CENTER);
        add(btnIconoCalendario, BorderLayout.EAST);
    }

    /**
     * Quita la flecha desplegable del selector de mes interno del {@link JCalendar}
     * e impide que el usuario pueda abrir la lista de meses al hacer clic.
     */
    private void desactivarDesplegableMes() {
        Component compMes = jCalendar.getMonthChooser().getComboBox();
        if (compMes instanceof JComboBox) {
            JComboBox<?> comboMes = (JComboBox<?>) compMes;
            comboMes.setUI(new BasicComboBoxUI() {
                @Override
                protected JButton createArrowButton() {
                    JButton btnVacio = new JButton();
                    btnVacio.setPreferredSize(new Dimension(0, 0));
                    btnVacio.setMinimumSize(new Dimension(0, 0));
                    btnVacio.setMaximumSize(new Dimension(0, 0));
                    btnVacio.setVisible(false);
                    return btnVacio;
                }

                @Override
                @SuppressWarnings("rawtypes")
                public void setPopupVisible(JComboBox c, boolean v) {
                    // Bloqueado para evitar que se abra el desplegable
                }
            });

            for (MouseListener ml : comboMes.getMouseListeners()) {
                comboMes.removeMouseListener(ml);
            }
            comboMes.setFocusable(false);
            comboMes.setBackground(Color.WHITE);
            comboMes.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(210, 215, 220)),
                    new EmptyBorder(2, 6, 2, 6)
            ));
        }
    }

    /**
     * Renderiza el fondo blanco del componente con esquinas redondeadas y un borde
     * sutil suavizado mediante antialiasing.
     *
     * @param g contexto gráfico {@link Graphics} utilizado para pintar el componente
     */
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 20, 20));
        g2.setColor(new Color(220, 228, 232));
        g2.draw(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 20, 20));
        g2.dispose();
        super.paintComponent(g);
    }

    /**
     * Obtiene la fecha actualmente seleccionada en el componente.
     *
     * @return objeto {@link LocalDate} con la fecha elegida, o {@code null} si aún no se ha seleccionado ninguna
     */
    public LocalDate getFecha() {
        return fechaSeleccionada;
    }

    /**
     * Establece programáticamente una fecha en el componente, sincronizando tanto el
     * calendario emergente interno como el texto visible en formato {@code dd/MM/yyyy}.
     *
     * @param fecha nueva fecha {@link LocalDate} a asignar; si es {@code null}, limpia el campo de texto
     */
    public void setFecha(LocalDate fecha) {
        this.fechaSeleccionada = fecha;
        if (fecha != null) {
            Date d = Date.from(fecha.atStartOfDay(ZoneId.systemDefault()).toInstant());
            jCalendar.setDate(d);
            txtFecha.setText(new SimpleDateFormat("dd/MM/yyyy").format(d));
        } else {
            txtFecha.setText("");
        }
    }

    /**
     * Devuelve la cadena de texto formateada que se muestra actualmente en la barra izquierda.
     *
     * @return texto visible en el campo de fecha (por ejemplo, {@code "12/06/2026"} o cadena vacía)
     */
    public String getTextoMostrado() {
        return txtFecha.getText();
    }

    /**
     * Icono vectorial dibujado mediante primitivas 2D que representa un calendario
     * sin depender de recursos externos de imagen.
     *
     * @author Alejandro Moreno Luna
     */
    private static class IconoCalendario implements Icon {

        /**
         * Dibuja el icono del calendario en las coordenadas especificadas.
         *
         * @param c componente anfitrión del icono
         * @param g contexto gráfico de renderizado
         * @param x coordenada horizontal inicial
         * @param y coordenada vertical inicial
         */
        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(55, 65, 81));
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(x + 2, y + 3, 14, 13, 3, 3);
            g2.drawLine(x + 2, y + 7, x + 16, y + 7);
            g2.drawLine(x + 6, y + 1, x + 6, y + 4);
            g2.drawLine(x + 12, y + 1, x + 12, y + 4);
            g2.dispose();
        }

        /**
         * Devuelve el ancho fijo del icono en píxeles.
         *
         * @return ancho del icono ({@code 18} px)
         */
        @Override
        public int getIconWidth() {
            return 18;
        }

        /**
         * Devuelve el alto fijo del icono en píxeles.
         *
         * @return alto del icono ({@code 18} px)
         */
        @Override
        public int getIconHeight() {
            return 18;
        }
    }
}