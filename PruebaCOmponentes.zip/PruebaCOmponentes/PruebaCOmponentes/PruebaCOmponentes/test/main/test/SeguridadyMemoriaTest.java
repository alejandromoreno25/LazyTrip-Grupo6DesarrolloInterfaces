package main.test;

import main.CampoCalendario;
import main.CampoReloj;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Suite de pruebas no funcionales (JUnit 5) para validar el consumo controlado
 * de memoria y la resistencia frente a vulnerabilidades básicas de entrada en
 * {@link CampoCalendario} y {@link CampoReloj}.
 *
 * @author Alejandro Moreno Luna
 * @version 1.0
 */
public class SeguridadyMemoriaTest {

    /**
     * SM-01: Verifica que instanciar y descartar 200 componentes de calendario y reloj
     * no provoca fugas de memoria ni supera el umbral de 64 MB de heap retenido.
     */
    @Test
    @DisplayName("SM-01: Control de consumo de memoria y ausencia de fugas")
    void testSM01_ConsumoMemoriaControlado() throws Exception {
        Runtime runtime = Runtime.getRuntime();
        System.gc();
        Thread.sleep(150);
        long memoriaInicial = runtime.totalMemory() - runtime.freeMemory();

        long inicioTiempo = System.currentTimeMillis();
        SwingUtilities.invokeAndWait(() -> {
            for (int i = 0; i < 200; i++) {
                CampoCalendario cal = new CampoCalendario();
                cal.setFecha(LocalDate.of(2026, 11, 25));

                CampoReloj rel = new CampoReloj();
                rel.setHora(LocalTime.of(14, 30));
            }
        });
        long duracionMs = System.currentTimeMillis() - inicioTiempo;

        System.gc();
        Thread.sleep(150);
        long memoriaFinal = runtime.totalMemory() - runtime.freeMemory();
        long deltaMB = Math.max(0, (memoriaFinal - memoriaInicial) / (1024 * 1024));

        assertTrue(deltaMB < 64, "El consumo de memoria residual debe ser inferior a 64 MB (fue " + deltaMB + " MB)");
        assertTrue(duracionMs < 3000, "La instanciación masiva debe completarse en menos de 3 segundos (tardó " + duracionMs + " ms)");
    }

    /**
     * SM-02: Verifica que los campos de texto internos son de solo lectura,
     * bloqueando la inyección directa de cadenas maliciosas o formatos inválidos.
     */
    @Test
    @DisplayName("SM-02: Protección contra inyección en campos de texto")
    void testSM02_CamposSoloLecturaContraInyeccion() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            CampoCalendario cal = new CampoCalendario();
            CampoReloj rel = new CampoReloj();

            JTextField txtCal = buscarTextField(cal);
            JTextField txtRel = buscarTextField(rel);

            assertNotNull(txtCal, "Debe existir el JTextField interno del calendario");
            assertNotNull(txtRel, "Debe existir el JTextField interno del reloj");

            assertFalse(txtCal.isEditable(), "El campo de fecha no debe permitir edición libre por teclado");
            assertFalse(txtRel.isEditable(), "El campo de hora no debe permitir edición libre por teclado");
        });
    }

    /**
     * SM-03: Verifica la robustez frente a entradas nulas y valores límite
     * (medianoche, fin de día y años bisiestos) sin lanzar excepciones.
     */
    @Test
    @DisplayName("SM-03: Robustez frente a valores nulos y límites")
    void testSM03_RobustezNulosYLimites() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            CampoCalendario cal = new CampoCalendario();
            CampoReloj rel = new CampoReloj();

            assertDoesNotThrow(() -> cal.setFecha(null));
            assertEquals("", cal.getTextoMostrado());

            assertDoesNotThrow(() -> cal.setFecha(LocalDate.of(2028, 2, 29)));
            assertEquals("29/02/2028", cal.getTextoMostrado());

            assertDoesNotThrow(() -> rel.setHora(null));
            assertEquals("", rel.getTextoMostrado());

            assertDoesNotThrow(() -> rel.setHora(LocalTime.of(0, 0)));
            assertEquals("00:00", rel.getTextoMostrado());

            assertDoesNotThrow(() -> rel.setHora(LocalTime.of(23, 59)));
            assertEquals("23:59", rel.getTextoMostrado());
        });
    }

    private JTextField buscarTextField(Container contenedor) {
        for (Component c : contenedor.getComponents()) {
            if (c instanceof JTextField tf) {
                return tf;
            }
        }
        return null;
    }
}