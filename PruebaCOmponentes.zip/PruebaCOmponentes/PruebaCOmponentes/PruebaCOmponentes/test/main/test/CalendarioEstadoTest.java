package main.test;

import com.toedter.calendar.JCalendar;
import main.CampoCalendario;
import org.junit.jupiter.api.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.InputEvent;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Suite de pruebas unitarias y de interfaz gráfica (JUnit 5 + Robot) para
 * validar el componente {@link CampoCalendario}.
 *
 * @author Alejandro Moreno Luna
 * @version 1.0
 */
public class CalendarioEstadoTest {

    private JFrame ventana;
    private CampoCalendario calendario;

    @BeforeEach
    void setUp() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            ventana = new JFrame("Test Calendario");
            ventana.setLayout(new FlowLayout());
            calendario = new CampoCalendario();
            ventana.add(calendario);
            ventana.pack();
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
        });
    }

    @AfterEach
    void tearDown() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            if (ventana != null) {
                ventana.dispose();
            }
        });
    }

    /**
     * CA-01: Comprueba que el selector inicia con fecha null, texto vacío
     * y el popup cerrado.
     */
    @Test
    @DisplayName("CA-01: Inicialización por defecto")
    void testCA01_Inicializacion() {
        assertNull(calendario.getFecha());
        assertEquals("", calendario.getTextoMostrado());
        assertFalse(buscarJCalendar().isShowing());
    }

    /**
     * CA-02: Simula clic con Robot en el botón derecho y comprueba que se abre
     * el desplegable del calendario.
     */
    @Test
    @DisplayName("CA-02: Apertura del calendario desplegable")
    void testCA02_AperturaCalendario() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            ventana.toFront();
            ventana.requestFocus();
        });

        JButton btnAbrir = (JButton) calendario.getComponent(1);
        Point p = btnAbrir.getLocationOnScreen();

        Robot robot = new Robot();
        robot.setAutoDelay(120);
        robot.mouseMove(p.x + btnAbrir.getWidth() / 2, p.y + btnAbrir.getHeight() / 2);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();

        assertTrue(buscarJCalendar().isShowing(), "El calendario debe mostrarse al pulsar el icono");
    }

    /**
     * CA-03: Comprueba la asignación y formateo de fecha en formato dd/MM/yyyy.
     */
    @Test
    @DisplayName("CA-03: Asignación y formateo de fecha")
    void testCA03_AsignacionYFormateo() throws Exception {
        SwingUtilities.invokeAndWait(() -> calendario.setFecha(LocalDate.of(2026, 11, 25)));

        assertEquals(LocalDate.of(2026, 11, 25), calendario.getFecha());
        assertEquals("25/11/2026", calendario.getTextoMostrado());
    }

    /**
     * CA-04: Comprueba que asignar null limpia la fecha y el texto mostrado.
     */
    @Test
    @DisplayName("CA-04: Limpieza de fecha con null")
    void testCA04_LimpiezaFecha() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            calendario.setFecha(LocalDate.of(2026, 11, 25));
            calendario.setFecha(null);
        });

        assertNull(calendario.getFecha());
        assertEquals("", calendario.getTextoMostrado());
    }

    private JCalendar buscarJCalendar() {
        for (Window w : Window.getWindows()) {
            if (w.isShowing()) {
                JCalendar encontrado = buscarRecursivo(w);
                if (encontrado != null) {
                    return encontrado;
                }
            }
        }
        return new JCalendar();
    }

    private JCalendar buscarRecursivo(Container c) {
        for (Component comp : c.getComponents()) {
            if (comp instanceof JCalendar jc) {
                return jc;
            }
            if (comp instanceof Container sub) {
                JCalendar res = buscarRecursivo(sub);
                if (res != null) {
                    return res;
                }
            }
        }
        return null;
    }
}