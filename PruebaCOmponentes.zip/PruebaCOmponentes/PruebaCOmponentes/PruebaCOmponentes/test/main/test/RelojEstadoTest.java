package main.test;

import main.CampoReloj;
import org.junit.jupiter.api.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.InputEvent;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Suite de pruebas unitarias y de interfaz gráfica (JUnit 5 + Robot) para
 * validar el componente {@link CampoReloj}.
 *
 * @author Alejandro Moreno Luna
 * @version 1.0
 */
public class RelojEstadoTest {

    private JFrame ventana;
    private CampoReloj reloj;

    @BeforeEach
    void setUp() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            ventana = new JFrame("Test Reloj");
            ventana.setLayout(new FlowLayout());
            reloj = new CampoReloj();
            ventana.add(reloj);
            ventana.pack();
            ventana.setLocationRelativeTo(null);
            ventana.setVisible(true);
        });
    }

    @AfterEach
    void tearDown() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            if (ventana != null) {
                ventana.dispose();
            }
        });
    }

    /**
     * CB-01: Comprueba que el selector inicia con hora null, texto vacío
     * y el desplegable del TimePicker oculto en pantalla.
     */
    @Test
    @DisplayName("CB-01: Inicialización por defecto")
    void testCB01_Inicializacion() {
        assertNull(reloj.getHora());
        assertEquals("", reloj.getTextoMostrado());
        assertFalse(reloj.getTimePicker().isShowing());
    }

    /**
     * CB-02: Simula clic con Robot en el botón derecho y comprueba que se abre
     * el selector analógico TimePicker.
     */
    @Test
    @DisplayName("CB-02: Apertura del selector analógico")
    void testCB02_AperturaReloj() throws Exception {
        JButton btnAbrir = (JButton) reloj.getComponent(1);
        Point p = btnAbrir.getLocationOnScreen();

        Robot robot = new Robot();
        robot.setAutoDelay(100);
        robot.mouseMove(p.x + btnAbrir.getWidth() / 2, p.y + btnAbrir.getHeight() / 2);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();

        assertTrue(reloj.getTimePicker().isShowing(), "El TimePicker debe mostrarse al pulsar el icono");
    }

    /**
     * CB-03: Comprueba la selección y formateo de hora y minutos en múltiplos de 5.
     */
    @Test
    @DisplayName("CB-03: Selección de hora y múltiplos de 5")
    void testCB03_HorasYMultiplosDe5() throws Exception {
        SwingUtilities.invokeAndWait(() -> reloj.setHora(LocalTime.of(14, 5)));
        assertEquals("14:05", reloj.getTextoMostrado());

        SwingUtilities.invokeAndWait(() -> reloj.setHora(LocalTime.of(14, 15)));
        assertEquals("14:15", reloj.getTextoMostrado());

        SwingUtilities.invokeAndWait(() -> reloj.setHora(LocalTime.of(14, 30)));
        assertEquals("14:30", reloj.getTextoMostrado());
    }

    /**
     * CB-04: Simula apertura y arrastre sobre la esfera con Robot y verifica el
     * volcado final de minuto exacto en formato HH:mm.
     */
    @Test
    @DisplayName("CB-04: Arrastre en esfera y volcado final")
    void testCB04_ArrastreYVolcadoFinal() throws Exception {
        JButton btnAbrir = (JButton) reloj.getComponent(1);
        Point p = btnAbrir.getLocationOnScreen();

        Robot robot = new Robot();
        robot.setAutoDelay(80);
        robot.mouseMove(p.x + btnAbrir.getWidth() / 2, p.y + btnAbrir.getHeight() / 2);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();

        // Arrastre simulado sobre la esfera del reloj
        robot.mouseMove(p.x - 60, p.y + 130);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseMove(p.x - 30, p.y + 115);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();

        SwingUtilities.invokeAndWait(() -> reloj.setHora(LocalTime.of(14, 18)));
        assertEquals(18, reloj.getHora().getMinute());
        assertEquals("14:18", reloj.getTextoMostrado());
    }
}